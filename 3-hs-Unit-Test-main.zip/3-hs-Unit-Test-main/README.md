<h1>Dondurma Projesi</h1>
İlk derslerde yazdığımız test ve kodlar İLKDERS klasörünün içinde yer alıyor.<br>
Geriye kalan dosyalar ikinci projeye aittir.

```
db.json
```

Dosyasından gerekli verileri koyalayabilirsiniz+

```
public/images
```

Klasöründen projedeki resimleri ulaşabilirsiniz

<h2>Teknolojiler </h2>
<p> React | Axios | Json-Server projeyi geliştirmek için kullanıldı. <p> 
<p>React Testing Library / Jest Unit testler için kullanıldı <p>
<h2>Preview</h2>
<img src="https://user-images.githubusercontent.com/109925130/216715044-49b9a719-6f3f-4da9-a650-9711564a6d22.gif" / >
