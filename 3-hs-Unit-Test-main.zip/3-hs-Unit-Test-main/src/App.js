import './App.css';
import WelcomePage from './pages/wecome-page/WelcomePage';

function App() {
  
  return (
    <div className="App">
      <WelcomePage />
    </div>
  );
}

export default App;
